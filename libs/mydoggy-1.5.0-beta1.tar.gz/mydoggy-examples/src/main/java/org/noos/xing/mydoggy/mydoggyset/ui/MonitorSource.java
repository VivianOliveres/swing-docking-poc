package org.noos.xing.mydoggy.mydoggyset.ui;

/**
 * @author Angelo De Caro
 */
public interface MonitorSource {

    float getTotal();

    float getUsed();

}
