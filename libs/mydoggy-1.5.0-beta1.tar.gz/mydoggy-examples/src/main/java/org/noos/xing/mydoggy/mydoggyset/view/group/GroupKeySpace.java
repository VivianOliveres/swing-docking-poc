package org.noos.xing.mydoggy.mydoggyset.view.group;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public enum GroupKeySpace {
    ADD_GROUP,
    REMOVE_GROUP,
    SHOW_GROUP,
    HIDE_GROUP,
    ADD_TOOL,
    REMOVE_TOOL,
    TOOL_ID,
    TOOL_IN_GROUP_ID,
}
