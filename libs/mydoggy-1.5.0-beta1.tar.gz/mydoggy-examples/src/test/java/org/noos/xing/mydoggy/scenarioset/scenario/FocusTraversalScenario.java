package org.noos.xing.mydoggy.scenarioset.scenario;

import org.noos.xing.mydoggy.scenario.AbstractScenario;

import java.awt.*;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public class FocusTraversalScenario extends AbstractScenario {

    public String getName() {
        return FocusTraversalScenario.class.getName();
    }

    public String getDescription() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Window launch() {
        return null;
    }
}
