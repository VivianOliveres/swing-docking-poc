package org.noos.xing.mydoggy.plaf.support;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

/**
 * @author Angelo De Caro
 */
public class CleanablePropertyChangeListener implements PropertyChangeListener {

    public void propertyChange(PropertyChangeEvent evt) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
