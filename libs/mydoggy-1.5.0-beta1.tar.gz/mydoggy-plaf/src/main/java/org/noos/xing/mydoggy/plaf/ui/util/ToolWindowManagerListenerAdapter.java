package org.noos.xing.mydoggy.plaf.ui.util;

import org.noos.xing.mydoggy.ToolWindowManagerListener;
import org.noos.xing.mydoggy.event.ToolWindowManagerEvent;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public class ToolWindowManagerListenerAdapter implements ToolWindowManagerListener {

    public void toolWindowRegistered(ToolWindowManagerEvent event) {
    }

    public void toolWindowUnregistered(ToolWindowManagerEvent event) {
    }

    public void toolWindowGroupAdded(ToolWindowManagerEvent event) {
    }

    public void toolWindowGroupRemoved(ToolWindowManagerEvent event) {
    }
}
