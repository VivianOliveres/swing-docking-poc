package org.noos.xing.mydoggy.plaf.cleaner;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface Cleaner {
    
    void cleanup();

}
