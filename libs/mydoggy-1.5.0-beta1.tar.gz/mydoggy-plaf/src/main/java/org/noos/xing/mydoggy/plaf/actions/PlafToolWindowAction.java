package org.noos.xing.mydoggy.plaf.actions;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface PlafToolWindowAction {
}
