package org.noos.xing.mydoggy.plaf.support;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
*/
public class DummyPropertyChangeListener implements PropertyChangeListener {

    public void propertyChange(PropertyChangeEvent evt) {
//            System.out.println("NTW - DUMMY : " + evt);
    }
    
}
